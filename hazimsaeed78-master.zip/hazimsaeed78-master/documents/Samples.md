# Links


[Работа с GO](https://github.com/mkaz/working-with-go)
