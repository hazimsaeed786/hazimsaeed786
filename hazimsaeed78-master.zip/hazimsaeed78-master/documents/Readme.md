## Раздел посвящен описанию полезных и интересных вещей для работы с GO
Новые идеи собраны из разных источников в том числе и из моей личнлой практике.   
Пользование как патернами в разработке так и в виде шпаркалки.    
Много трудов разных авторов.   

### Book
[Книга по GO](https://github.com/astaxie/build-web-application-with-golang/blob/master/ru/preface.md)
[Sample](https://gobyexample.com/)



