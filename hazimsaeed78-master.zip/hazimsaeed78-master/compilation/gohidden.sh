Запустить в процессах для Windows

go build -ldflags "-H windowsgui"  
