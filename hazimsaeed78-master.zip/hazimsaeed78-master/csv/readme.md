
## thanks to the author
[Convert csv to json](https://socketloop.com/tutorials/golang-convert-csv-data-to-json-format-and-save-to-file)
