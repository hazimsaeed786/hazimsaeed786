https://play.golang.com/p/vTnynyXgs_l
