
echo Start building process

# Start parser with the path to the config.yml ./
go build -o conf && ./conf



