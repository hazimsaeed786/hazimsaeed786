

```go
rand.Seed(time.Now().Unix())
temp := rand.Intn(n * 2)
```

