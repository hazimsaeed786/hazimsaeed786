# SNIPPETS
![image](https://user-images.githubusercontent.com/3950155/198528673-24ae03ed-4815-4e5a-bc54-9e9c85ba1dbf.png)

* Usful templates for everyday used 
* For simple use in your projects  
* And for systematization information in work for complicated tasks   
