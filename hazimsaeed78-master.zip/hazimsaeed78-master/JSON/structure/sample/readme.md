## Работа с JSON
![Alt Text](https://media.giphy.com/media/vFKqnCdLPNOKc/giphy.gif)
При получении JSON файла с помощью сервиса, преобразуем его
согласно структуре .

1. Необходимо преобразовать его согласно нашей структуре   
2. Необходимо вернуть данные согласно так же нашей структуре     

![Alt Text](https://github.com/Gitart/GO-SIMPLE/blob/master/JSON/structure/sample/Json-encoding.png)

