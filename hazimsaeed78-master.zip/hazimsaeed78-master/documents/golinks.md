## LINKS FOR GO

# ("GO")[http://eax.me/go-rest-service/]
