Links
IDE
http://geekmonkey.org/2012/09/comparison-of-ides-for-google-go/
