
![image](https://github.com/Gitart/GO-SIMPLE/assets/3950155/b5a5dbdd-cb13-44ed-ab07-0e863c28c42d)

## Add new
GET http://localhost:1234/addkey/key21/51

```json
{
    "title":"ssss",
    "num":"W3--3",
    "price":{{$randomPrice}}
}
```
## Get key
http://localhost:1234/getkey/key21
