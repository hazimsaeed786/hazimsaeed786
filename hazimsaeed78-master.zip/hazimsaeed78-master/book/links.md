## BOOKS

#### Шпаргалки   
https://leanpub.com/gocrypto/read  
https://tproger.ru/digest/top-cheatsheets/  
https://leanpub.com/gocrypto/read#leanpub-auto-aes-cbc    
https://thewhitetulip.gitbooks.io/webapp-with-golang-anti-textbook/content/  
http://openmymind.net/The-Little-Go-Book/  
https://thewhitetulip.gitbooks.io/webapp-with-golang-anti-textbook/content/  
https://leanpub.com/antitextbookGo   
https://miek.nl/go/   
https://miek.nl/files/go/Learning-Go-latest.pdf   
https://astaxie.gitbooks.io/build-web-application-with-golang/content/en/  
https://www.gitbook.com/book/astaxie/build-web-application-with-golang/details  
https://codegangsta.gitbooks.io/building-web-apps-with-go/content/  
https://www.gitbook.com/book/codegangsta/building-web-apps-with-go/details  
http://www.golangbootcamp.com/book
http://www.golang-book.com/books/intro   
http://www.golang-book.com/public/pdf/gobook.0.pdf  

