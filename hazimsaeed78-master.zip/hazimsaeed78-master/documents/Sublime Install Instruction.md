
## Инструкция по установкке дополнений к Sublime


1. CD c:\Users\a.savchenko\AppData\Roaming\Sublime Text 3\Packages\
2. Скачивать  GoSublime-master   - здесь : https://github.com/nsf/gocode
3. Переименовать GoSublime-master в GoSublime
4. И записать по указанному верху пути c:\Users\a.savchenko\AppData\Roaming\Sublime Text 3\Packages\GoSublime

Получаем : автозаполнение текста для GO
                                      
